public class OpTuple {
    public final String text;
    public final String dest;
    public OpTuple(String text, String dest) {
        this.text = text;
        this.dest = dest;
    }
}